use `plat_desarrollo`;

Create database if not exists plat_desarrollo;


drop table if exists usuarios;
CREATE TABLE IF NOT EXISTS usuarios(
    Id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Nombre varchar(20) NOT NULL,
    Contraseña varchar(20) NOT NULL
);

insert into usuarios (Nombre, Contraseña)
values ("admin", "admin"),
("ignacio", "1234"),
("nacho", "nacho123");

select * from usuarios;
