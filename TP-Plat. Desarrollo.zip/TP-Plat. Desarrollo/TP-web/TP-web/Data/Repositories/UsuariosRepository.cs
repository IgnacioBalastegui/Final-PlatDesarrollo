﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TP_web.Models;
using Dapper;

namespace TP_web.Data.Repositories
{
    public class UsuariosRepository : IUsuariosRepository
    {

        private MySQLConfiguration _connectionString;

        public UsuariosRepository(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }

       /* public Task<bool> DeleteUsuarios(Usuarios user)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Usuarios>> GetAllUsuarios()
        {
            throw new NotImplementedException();
        }*/
       /*
        public async Task<Usuarios> GetUsuariosDetails( string nombre, string password)
        {

            var db = dbConnection();

            var sql = @"SELECT Nombre, Contraseña FROM usuarios WHERE Nombre LIKE @nombre AND Contraseña LIKE @password";

            return await db.QueryFirstOrDefaultAsync<Usuarios>(sql, new { nombre = nombre, password = password });

        }*/

        public async Task<bool> InsertUsuarios( Usuarios user)
        {
            var db = dbConnection();

            var sql = @"INSERT INTO usuarios(Nombre, Contraseña) VALUES (@nombre, @password)";

            var result = await db.ExecuteAsync(sql, new { user.Nombre, user.Contraseña });

            return result > 0;
        }

     /*   public Task<bool> UpdateUsuarios(Usuarios user)
        {
            throw new NotImplementedException();
        }*/
    }
}
