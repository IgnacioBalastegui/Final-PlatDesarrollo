﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TP_web.Models;

namespace TP_web.Data.Repositories
{
    interface IUsuariosRepository
    {
      // Task<IEnumerable<Usuarios>> GetAllUsuarios();

       // Task<Usuarios> GetUsuariosDetails(string nombre, string password);

        Task<bool> InsertUsuarios(Usuarios user);

    /*    Task<bool> UpdateUsuarios(Usuarios user);

        Task<bool> DeleteUsuarios(Usuarios user);*/
    }
}
