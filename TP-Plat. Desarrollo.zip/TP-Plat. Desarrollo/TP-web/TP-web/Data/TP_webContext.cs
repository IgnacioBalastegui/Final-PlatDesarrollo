﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TP_web.Models;

namespace TP_web.Data
{
    public class TP_webContext : DbContext
    {
        public TP_webContext (DbContextOptions<TP_webContext> options)
            : base(options)
        {
        }

        public DbSet<TP_web.Models.Usuarios> Usuarios { get; set; }
    }
}
