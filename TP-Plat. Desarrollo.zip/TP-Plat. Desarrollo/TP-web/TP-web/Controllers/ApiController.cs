﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TP_web.Data.Repositories;
using TP_web.Models;

namespace TP_web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        private readonly IUsuariosRepository _usuariosRepository;

        /* public ApiController(IUsuariosRepository usuariosRepository)
         {
             _usuariosRepository = usuariosRepository;
         }*/

        /*
                [HttpGet ("{nombre, password}")]
                public async Task<IActionResult> GetUsuariosDetails( string nombre, string password)
                {
                    return Ok(await _usuariosRepository.GetUsuariosDetails(nombre, password));
                }

        */
        [HttpPost]
        public async Task<IActionResult> CreateUsuario([FromBody] Usuarios usuarios)
        {
            if(usuarios == null)
            {
                return BadRequest();
            }
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            var created = await _usuariosRepository.InsertUsuarios(usuarios);
            return Created("created", created);
        }
    }
}
