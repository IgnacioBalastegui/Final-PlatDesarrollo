﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.Entity;

namespace TP_web.Models
{
    public class Usuarios
    {

        public int Id { get; set; }

        public string Nombre { get; set; }

        public string Contraseña { get; set; }
    }

   
}
