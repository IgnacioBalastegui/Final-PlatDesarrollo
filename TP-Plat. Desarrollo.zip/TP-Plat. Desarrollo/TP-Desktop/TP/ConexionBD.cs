﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP
{
    class ConexionBD
    {
        public static MySqlConnection establecerConexion()
        {
            string servidor = "localhost";
            string bd = "plat_desarrollo";
            string usuario = "root";
            string password = "";
            string puerto = "3306";

            string cadenaConexion = "server=" + servidor + ";" + "port=" + puerto + ";" + "user id=" + usuario + ";"
                + "password=" + password + ";" + "database=" + bd + ";";
            try
            {
                MySqlConnection conex = new MySqlConnection(cadenaConexion);
                return conex;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("no se pudo conectar a la base de datos, error: " + e.Message);
                //no se pudo conectar a la base de datos
                return null;
            }


        }
    }
}
