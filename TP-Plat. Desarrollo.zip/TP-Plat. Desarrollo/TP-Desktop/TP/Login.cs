﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var boton = (Button)sender;

            string nombre = textBoxUsuario.Text;
            string password = textBoxContrasenia.Text;
                       
          MySqlDataReader reader = null;

          string sql = "SELECT Nombre, Contraseña FROM usuarios WHERE Nombre LIKE '"+ nombre+"'"
              +"AND Contraseña LIKE '"+password+ "'";

          MySqlConnection conexion = ConexionBD.establecerConexion();
          conexion.Open();
          try
          {
              MySqlCommand comando = new MySqlCommand(sql, conexion);
              reader = comando.ExecuteReader();
            if(reader.HasRows)
            {
                MessageBox.Show("Logueado correctamente", "Listo");
                    App app = new App();
                    app.Show();
                    this.Hide();
                app.labelBienvenido.Text = "Bienvenido " + nombre;
            }
            else
            {
                MessageBox.Show("Credenciales incorrectas", "Error");
            }
          }
          catch (MySqlException ex)
          {
              MessageBox.Show("Error al buscar, "+ ex.Message);
          }
          finally
          {
              conexion.Close();
          }
            /*
            if (credencialesCorrectas())
                {
                    MessageBox.Show("Logueado correctamente", "Listo");
                    App app = new App();
                    app.Show();
                    this.Hide();
                app.labelBienvenido.Text = "Bienvenido " + nombre;
                }
                else
                {
                    MessageBox.Show("Credenciales incorrectas", "Error");
                }
            */
        }

       /* public bool credencialesCorrectas()
        {
            string nombre = textBoxUsuario.Text;
            string password = textBoxContrasenia.Text;

            return nombre.Equals("ignacio") && password.Equals("ignacio123");
        }*/

    }
}
