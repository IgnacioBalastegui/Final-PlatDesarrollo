﻿
namespace TP
{
    partial class App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonExtraerImagenDelVideo = new System.Windows.Forms.Button();
            this.buttonCambiarResolucionDelVideo = new System.Windows.Forms.Button();
            this.buttonRemoverAudioDelVideo = new System.Windows.Forms.Button();
            this.buttonExtraerAudioDelVideo = new System.Windows.Forms.Button();
            this.buttonCambiarFormatoDelVideo = new System.Windows.Forms.Button();
            this.TabControlPrincipal = new System.Windows.Forms.TabControl();
            this.tabPageCambiarFormato = new System.Windows.Forms.TabPage();
            this.buttonConvertirFormato = new System.Windows.Forms.Button();
            this.textBoxNuevoArchivo1 = new System.Windows.Forms.TextBox();
            this.labelNuevoArchivo1 = new System.Windows.Forms.Label();
            this.comboBoxFormatos = new System.Windows.Forms.ComboBox();
            this.labelSeleccionarFormato = new System.Windows.Forms.Label();
            this.buttonBuscar1 = new System.Windows.Forms.Button();
            this.textBoxArchivo1 = new System.Windows.Forms.TextBox();
            this.labelCambiarFormato = new System.Windows.Forms.Label();
            this.tabPageExtraerAudio = new System.Windows.Forms.TabPage();
            this.buttonExtraerAudio = new System.Windows.Forms.Button();
            this.textBoxNuevoArchivo2 = new System.Windows.Forms.TextBox();
            this.labelNuevoArchivo2 = new System.Windows.Forms.Label();
            this.buttonBuscar2 = new System.Windows.Forms.Button();
            this.textBoxArchivo2 = new System.Windows.Forms.TextBox();
            this.labelExtraerAudio = new System.Windows.Forms.Label();
            this.tabPageRemoverAudio = new System.Windows.Forms.TabPage();
            this.buttonRemoverAudio = new System.Windows.Forms.Button();
            this.textBoxNuevoArchivo3 = new System.Windows.Forms.TextBox();
            this.labelNuevoArchivo3 = new System.Windows.Forms.Label();
            this.buttonBuscar3 = new System.Windows.Forms.Button();
            this.textBoxArchivo3 = new System.Windows.Forms.TextBox();
            this.labelRemoverAudio = new System.Windows.Forms.Label();
            this.tabPageCambiarResolucion = new System.Windows.Forms.TabPage();
            this.textBoxAncho = new System.Windows.Forms.TextBox();
            this.textBoxAlto = new System.Windows.Forms.TextBox();
            this.labelAncho = new System.Windows.Forms.Label();
            this.labelAlto = new System.Windows.Forms.Label();
            this.buttonCambiarResolucion = new System.Windows.Forms.Button();
            this.textBoxNuevoArchivo4 = new System.Windows.Forms.TextBox();
            this.labelNuevoArchivo4 = new System.Windows.Forms.Label();
            this.buttonBuscar4 = new System.Windows.Forms.Button();
            this.textBoxArchivo4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPageExtraerImagen = new System.Windows.Forms.TabPage();
            this.textBoxFps = new System.Windows.Forms.TextBox();
            this.labelFps = new System.Windows.Forms.Label();
            this.buttonExtraerImagen = new System.Windows.Forms.Button();
            this.textBoxNuevoArchivo5 = new System.Windows.Forms.TextBox();
            this.labelNuevoArchivo5 = new System.Windows.Forms.Label();
            this.buttonBuscar5 = new System.Windows.Forms.Button();
            this.textBoxArchivo5 = new System.Windows.Forms.TextBox();
            this.labelExtraerImagen = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonCerrar = new System.Windows.Forms.Button();
            this.labelBienvenido = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.TabControlPrincipal.SuspendLayout();
            this.tabPageCambiarFormato.SuspendLayout();
            this.tabPageExtraerAudio.SuspendLayout();
            this.tabPageRemoverAudio.SuspendLayout();
            this.tabPageCambiarResolucion.SuspendLayout();
            this.tabPageExtraerImagen.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.buttonExtraerImagenDelVideo);
            this.panel3.Controls.Add(this.buttonCambiarResolucionDelVideo);
            this.panel3.Controls.Add(this.buttonRemoverAudioDelVideo);
            this.panel3.Controls.Add(this.buttonExtraerAudioDelVideo);
            this.panel3.Controls.Add(this.buttonCambiarFormatoDelVideo);
            this.panel3.Location = new System.Drawing.Point(-1, 112);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(206, 343);
            this.panel3.TabIndex = 3;
            // 
            // buttonExtraerImagenDelVideo
            // 
            this.buttonExtraerImagenDelVideo.Location = new System.Drawing.Point(27, 277);
            this.buttonExtraerImagenDelVideo.Name = "buttonExtraerImagenDelVideo";
            this.buttonExtraerImagenDelVideo.Size = new System.Drawing.Size(133, 48);
            this.buttonExtraerImagenDelVideo.TabIndex = 4;
            this.buttonExtraerImagenDelVideo.Text = "Extraer imagenes del video";
            this.buttonExtraerImagenDelVideo.UseVisualStyleBackColor = true;
            this.buttonExtraerImagenDelVideo.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonCambiarResolucionDelVideo
            // 
            this.buttonCambiarResolucionDelVideo.Location = new System.Drawing.Point(27, 212);
            this.buttonCambiarResolucionDelVideo.Name = "buttonCambiarResolucionDelVideo";
            this.buttonCambiarResolucionDelVideo.Size = new System.Drawing.Size(133, 48);
            this.buttonCambiarResolucionDelVideo.TabIndex = 3;
            this.buttonCambiarResolucionDelVideo.Text = "Cambiar resolucion del video";
            this.buttonCambiarResolucionDelVideo.UseVisualStyleBackColor = true;
            this.buttonCambiarResolucionDelVideo.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonRemoverAudioDelVideo
            // 
            this.buttonRemoverAudioDelVideo.Location = new System.Drawing.Point(27, 146);
            this.buttonRemoverAudioDelVideo.Name = "buttonRemoverAudioDelVideo";
            this.buttonRemoverAudioDelVideo.Size = new System.Drawing.Size(133, 48);
            this.buttonRemoverAudioDelVideo.TabIndex = 2;
            this.buttonRemoverAudioDelVideo.Text = "Remover audio del video";
            this.buttonRemoverAudioDelVideo.UseVisualStyleBackColor = true;
            this.buttonRemoverAudioDelVideo.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonExtraerAudioDelVideo
            // 
            this.buttonExtraerAudioDelVideo.Location = new System.Drawing.Point(27, 79);
            this.buttonExtraerAudioDelVideo.Name = "buttonExtraerAudioDelVideo";
            this.buttonExtraerAudioDelVideo.Size = new System.Drawing.Size(133, 48);
            this.buttonExtraerAudioDelVideo.TabIndex = 1;
            this.buttonExtraerAudioDelVideo.Text = "Extraer audio del video";
            this.buttonExtraerAudioDelVideo.UseVisualStyleBackColor = true;
            this.buttonExtraerAudioDelVideo.Click += new System.EventHandler(this.button3_Click);
            // 
            // buttonCambiarFormatoDelVideo
            // 
            this.buttonCambiarFormatoDelVideo.Location = new System.Drawing.Point(27, 14);
            this.buttonCambiarFormatoDelVideo.Name = "buttonCambiarFormatoDelVideo";
            this.buttonCambiarFormatoDelVideo.Size = new System.Drawing.Size(133, 48);
            this.buttonCambiarFormatoDelVideo.TabIndex = 0;
            this.buttonCambiarFormatoDelVideo.Text = "Cambiar formato del video";
            this.buttonCambiarFormatoDelVideo.UseVisualStyleBackColor = true;
            this.buttonCambiarFormatoDelVideo.Click += new System.EventHandler(this.button2_Click);
            // 
            // TabControlPrincipal
            // 
            this.TabControlPrincipal.Controls.Add(this.tabPageCambiarFormato);
            this.TabControlPrincipal.Controls.Add(this.tabPageExtraerAudio);
            this.TabControlPrincipal.Controls.Add(this.tabPageRemoverAudio);
            this.TabControlPrincipal.Controls.Add(this.tabPageCambiarResolucion);
            this.TabControlPrincipal.Controls.Add(this.tabPageExtraerImagen);
            this.TabControlPrincipal.Location = new System.Drawing.Point(198, 89);
            this.TabControlPrincipal.Name = "TabControlPrincipal";
            this.TabControlPrincipal.SelectedIndex = 0;
            this.TabControlPrincipal.Size = new System.Drawing.Size(603, 366);
            this.TabControlPrincipal.TabIndex = 4;
            // 
            // tabPageCambiarFormato
            // 
            this.tabPageCambiarFormato.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageCambiarFormato.Controls.Add(this.buttonConvertirFormato);
            this.tabPageCambiarFormato.Controls.Add(this.textBoxNuevoArchivo1);
            this.tabPageCambiarFormato.Controls.Add(this.labelNuevoArchivo1);
            this.tabPageCambiarFormato.Controls.Add(this.comboBoxFormatos);
            this.tabPageCambiarFormato.Controls.Add(this.labelSeleccionarFormato);
            this.tabPageCambiarFormato.Controls.Add(this.buttonBuscar1);
            this.tabPageCambiarFormato.Controls.Add(this.textBoxArchivo1);
            this.tabPageCambiarFormato.Controls.Add(this.labelCambiarFormato);
            this.tabPageCambiarFormato.Location = new System.Drawing.Point(4, 22);
            this.tabPageCambiarFormato.Name = "tabPageCambiarFormato";
            this.tabPageCambiarFormato.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCambiarFormato.Size = new System.Drawing.Size(595, 340);
            this.tabPageCambiarFormato.TabIndex = 0;
            this.tabPageCambiarFormato.Text = "tabPage1";
            // 
            // buttonConvertirFormato
            // 
            this.buttonConvertirFormato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConvertirFormato.Location = new System.Drawing.Point(252, 285);
            this.buttonConvertirFormato.Name = "buttonConvertirFormato";
            this.buttonConvertirFormato.Size = new System.Drawing.Size(90, 35);
            this.buttonConvertirFormato.TabIndex = 7;
            this.buttonConvertirFormato.Text = "Convertir";
            this.buttonConvertirFormato.UseVisualStyleBackColor = true;
            this.buttonConvertirFormato.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBoxNuevoArchivo1
            // 
            this.textBoxNuevoArchivo1.Location = new System.Drawing.Point(329, 230);
            this.textBoxNuevoArchivo1.Name = "textBoxNuevoArchivo1";
            this.textBoxNuevoArchivo1.Size = new System.Drawing.Size(169, 20);
            this.textBoxNuevoArchivo1.TabIndex = 6;
            // 
            // labelNuevoArchivo1
            // 
            this.labelNuevoArchivo1.AutoSize = true;
            this.labelNuevoArchivo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNuevoArchivo1.Location = new System.Drawing.Point(95, 231);
            this.labelNuevoArchivo1.Name = "labelNuevoArchivo1";
            this.labelNuevoArchivo1.Size = new System.Drawing.Size(228, 17);
            this.labelNuevoArchivo1.TabIndex = 5;
            this.labelNuevoArchivo1.Text = "Colocar nuevo nombre del archivo:";
            // 
            // comboBoxFormatos
            // 
            this.comboBoxFormatos.FormattingEnabled = true;
            this.comboBoxFormatos.Items.AddRange(new object[] {
            "mp4",
            "avi",
            "mpeg",
            "flv"});
            this.comboBoxFormatos.Location = new System.Drawing.Point(294, 166);
            this.comboBoxFormatos.Name = "comboBoxFormatos";
            this.comboBoxFormatos.Size = new System.Drawing.Size(125, 21);
            this.comboBoxFormatos.TabIndex = 4;
            // 
            // labelSeleccionarFormato
            // 
            this.labelSeleccionarFormato.AutoSize = true;
            this.labelSeleccionarFormato.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeleccionarFormato.Location = new System.Drawing.Point(107, 167);
            this.labelSeleccionarFormato.Name = "labelSeleccionarFormato";
            this.labelSeleccionarFormato.Size = new System.Drawing.Size(181, 17);
            this.labelSeleccionarFormato.TabIndex = 3;
            this.labelSeleccionarFormato.Text = "Seleccionar nuevo formato:";
            // 
            // buttonBuscar1
            // 
            this.buttonBuscar1.Location = new System.Drawing.Point(366, 94);
            this.buttonBuscar1.Name = "buttonBuscar1";
            this.buttonBuscar1.Size = new System.Drawing.Size(75, 23);
            this.buttonBuscar1.TabIndex = 2;
            this.buttonBuscar1.Text = "Buscar";
            this.buttonBuscar1.UseVisualStyleBackColor = true;
            this.buttonBuscar1.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBoxArchivo1
            // 
            this.textBoxArchivo1.Enabled = false;
            this.textBoxArchivo1.Location = new System.Drawing.Point(145, 96);
            this.textBoxArchivo1.Name = "textBoxArchivo1";
            this.textBoxArchivo1.Size = new System.Drawing.Size(215, 20);
            this.textBoxArchivo1.TabIndex = 1;
            // 
            // labelCambiarFormato
            // 
            this.labelCambiarFormato.AutoSize = true;
            this.labelCambiarFormato.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCambiarFormato.Location = new System.Drawing.Point(187, 42);
            this.labelCambiarFormato.Name = "labelCambiarFormato";
            this.labelCambiarFormato.Size = new System.Drawing.Size(219, 22);
            this.labelCambiarFormato.TabIndex = 0;
            this.labelCambiarFormato.Text = "Cambiar formato del video";
            // 
            // tabPageExtraerAudio
            // 
            this.tabPageExtraerAudio.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageExtraerAudio.Controls.Add(this.buttonExtraerAudio);
            this.tabPageExtraerAudio.Controls.Add(this.textBoxNuevoArchivo2);
            this.tabPageExtraerAudio.Controls.Add(this.labelNuevoArchivo2);
            this.tabPageExtraerAudio.Controls.Add(this.buttonBuscar2);
            this.tabPageExtraerAudio.Controls.Add(this.textBoxArchivo2);
            this.tabPageExtraerAudio.Controls.Add(this.labelExtraerAudio);
            this.tabPageExtraerAudio.Location = new System.Drawing.Point(4, 22);
            this.tabPageExtraerAudio.Name = "tabPageExtraerAudio";
            this.tabPageExtraerAudio.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageExtraerAudio.Size = new System.Drawing.Size(595, 340);
            this.tabPageExtraerAudio.TabIndex = 1;
            this.tabPageExtraerAudio.Text = "tabPage2";
            // 
            // buttonExtraerAudio
            // 
            this.buttonExtraerAudio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExtraerAudio.Location = new System.Drawing.Point(249, 265);
            this.buttonExtraerAudio.Name = "buttonExtraerAudio";
            this.buttonExtraerAudio.Size = new System.Drawing.Size(90, 35);
            this.buttonExtraerAudio.TabIndex = 14;
            this.buttonExtraerAudio.Text = "Extraer";
            this.buttonExtraerAudio.UseVisualStyleBackColor = true;
            this.buttonExtraerAudio.Click += new System.EventHandler(this.button10_Click);
            // 
            // textBoxNuevoArchivo2
            // 
            this.textBoxNuevoArchivo2.Location = new System.Drawing.Point(314, 197);
            this.textBoxNuevoArchivo2.Name = "textBoxNuevoArchivo2";
            this.textBoxNuevoArchivo2.Size = new System.Drawing.Size(169, 20);
            this.textBoxNuevoArchivo2.TabIndex = 13;
            // 
            // labelNuevoArchivo2
            // 
            this.labelNuevoArchivo2.AutoSize = true;
            this.labelNuevoArchivo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNuevoArchivo2.Location = new System.Drawing.Point(80, 198);
            this.labelNuevoArchivo2.Name = "labelNuevoArchivo2";
            this.labelNuevoArchivo2.Size = new System.Drawing.Size(228, 17);
            this.labelNuevoArchivo2.TabIndex = 12;
            this.labelNuevoArchivo2.Text = "Colocar nuevo nombre del archivo:";
            // 
            // buttonBuscar2
            // 
            this.buttonBuscar2.Location = new System.Drawing.Point(361, 118);
            this.buttonBuscar2.Name = "buttonBuscar2";
            this.buttonBuscar2.Size = new System.Drawing.Size(75, 23);
            this.buttonBuscar2.TabIndex = 9;
            this.buttonBuscar2.Text = "Buscar";
            this.buttonBuscar2.UseVisualStyleBackColor = true;
            this.buttonBuscar2.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBoxArchivo2
            // 
            this.textBoxArchivo2.Enabled = false;
            this.textBoxArchivo2.Location = new System.Drawing.Point(140, 120);
            this.textBoxArchivo2.Name = "textBoxArchivo2";
            this.textBoxArchivo2.Size = new System.Drawing.Size(215, 20);
            this.textBoxArchivo2.TabIndex = 8;
            // 
            // labelExtraerAudio
            // 
            this.labelExtraerAudio.AutoSize = true;
            this.labelExtraerAudio.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelExtraerAudio.Location = new System.Drawing.Point(118, 58);
            this.labelExtraerAudio.Name = "labelExtraerAudio";
            this.labelExtraerAudio.Size = new System.Drawing.Size(328, 22);
            this.labelExtraerAudio.TabIndex = 7;
            this.labelExtraerAudio.Text = "Extraer audio del video en formato .mp3";
            // 
            // tabPageRemoverAudio
            // 
            this.tabPageRemoverAudio.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageRemoverAudio.Controls.Add(this.buttonRemoverAudio);
            this.tabPageRemoverAudio.Controls.Add(this.textBoxNuevoArchivo3);
            this.tabPageRemoverAudio.Controls.Add(this.labelNuevoArchivo3);
            this.tabPageRemoverAudio.Controls.Add(this.buttonBuscar3);
            this.tabPageRemoverAudio.Controls.Add(this.textBoxArchivo3);
            this.tabPageRemoverAudio.Controls.Add(this.labelRemoverAudio);
            this.tabPageRemoverAudio.Location = new System.Drawing.Point(4, 22);
            this.tabPageRemoverAudio.Name = "tabPageRemoverAudio";
            this.tabPageRemoverAudio.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRemoverAudio.Size = new System.Drawing.Size(595, 340);
            this.tabPageRemoverAudio.TabIndex = 2;
            this.tabPageRemoverAudio.Text = "tabPage3";
            // 
            // buttonRemoverAudio
            // 
            this.buttonRemoverAudio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRemoverAudio.Location = new System.Drawing.Point(265, 254);
            this.buttonRemoverAudio.Name = "buttonRemoverAudio";
            this.buttonRemoverAudio.Size = new System.Drawing.Size(90, 35);
            this.buttonRemoverAudio.TabIndex = 20;
            this.buttonRemoverAudio.Text = "Remover";
            this.buttonRemoverAudio.UseVisualStyleBackColor = true;
            this.buttonRemoverAudio.Click += new System.EventHandler(this.button11_Click);
            // 
            // textBoxNuevoArchivo3
            // 
            this.textBoxNuevoArchivo3.Location = new System.Drawing.Point(330, 186);
            this.textBoxNuevoArchivo3.Name = "textBoxNuevoArchivo3";
            this.textBoxNuevoArchivo3.Size = new System.Drawing.Size(169, 20);
            this.textBoxNuevoArchivo3.TabIndex = 19;
            // 
            // labelNuevoArchivo3
            // 
            this.labelNuevoArchivo3.AutoSize = true;
            this.labelNuevoArchivo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNuevoArchivo3.Location = new System.Drawing.Point(96, 187);
            this.labelNuevoArchivo3.Name = "labelNuevoArchivo3";
            this.labelNuevoArchivo3.Size = new System.Drawing.Size(228, 17);
            this.labelNuevoArchivo3.TabIndex = 18;
            this.labelNuevoArchivo3.Text = "Colocar nuevo nombre del archivo:";
            // 
            // buttonBuscar3
            // 
            this.buttonBuscar3.Location = new System.Drawing.Point(377, 107);
            this.buttonBuscar3.Name = "buttonBuscar3";
            this.buttonBuscar3.Size = new System.Drawing.Size(75, 23);
            this.buttonBuscar3.TabIndex = 17;
            this.buttonBuscar3.Text = "Buscar";
            this.buttonBuscar3.UseVisualStyleBackColor = true;
            this.buttonBuscar3.Click += new System.EventHandler(this.button12_Click);
            // 
            // textBoxArchivo3
            // 
            this.textBoxArchivo3.Enabled = false;
            this.textBoxArchivo3.Location = new System.Drawing.Point(156, 109);
            this.textBoxArchivo3.Name = "textBoxArchivo3";
            this.textBoxArchivo3.Size = new System.Drawing.Size(215, 20);
            this.textBoxArchivo3.TabIndex = 16;
            // 
            // labelRemoverAudio
            // 
            this.labelRemoverAudio.AutoSize = true;
            this.labelRemoverAudio.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRemoverAudio.Location = new System.Drawing.Point(198, 51);
            this.labelRemoverAudio.Name = "labelRemoverAudio";
            this.labelRemoverAudio.Size = new System.Drawing.Size(208, 22);
            this.labelRemoverAudio.TabIndex = 15;
            this.labelRemoverAudio.Text = "Remover audio del video";
            // 
            // tabPageCambiarResolucion
            // 
            this.tabPageCambiarResolucion.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageCambiarResolucion.Controls.Add(this.textBoxAncho);
            this.tabPageCambiarResolucion.Controls.Add(this.textBoxAlto);
            this.tabPageCambiarResolucion.Controls.Add(this.labelAncho);
            this.tabPageCambiarResolucion.Controls.Add(this.labelAlto);
            this.tabPageCambiarResolucion.Controls.Add(this.buttonCambiarResolucion);
            this.tabPageCambiarResolucion.Controls.Add(this.textBoxNuevoArchivo4);
            this.tabPageCambiarResolucion.Controls.Add(this.labelNuevoArchivo4);
            this.tabPageCambiarResolucion.Controls.Add(this.buttonBuscar4);
            this.tabPageCambiarResolucion.Controls.Add(this.textBoxArchivo4);
            this.tabPageCambiarResolucion.Controls.Add(this.label10);
            this.tabPageCambiarResolucion.Location = new System.Drawing.Point(4, 22);
            this.tabPageCambiarResolucion.Name = "tabPageCambiarResolucion";
            this.tabPageCambiarResolucion.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCambiarResolucion.Size = new System.Drawing.Size(595, 340);
            this.tabPageCambiarResolucion.TabIndex = 3;
            this.tabPageCambiarResolucion.Text = "tabPage4";
            // 
            // textBoxAncho
            // 
            this.textBoxAncho.Location = new System.Drawing.Point(205, 161);
            this.textBoxAncho.Name = "textBoxAncho";
            this.textBoxAncho.Size = new System.Drawing.Size(73, 20);
            this.textBoxAncho.TabIndex = 30;
            // 
            // textBoxAlto
            // 
            this.textBoxAlto.Location = new System.Drawing.Point(377, 163);
            this.textBoxAlto.Name = "textBoxAlto";
            this.textBoxAlto.Size = new System.Drawing.Size(64, 20);
            this.textBoxAlto.TabIndex = 29;
            // 
            // labelAncho
            // 
            this.labelAncho.AutoSize = true;
            this.labelAncho.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAncho.Location = new System.Drawing.Point(140, 161);
            this.labelAncho.Name = "labelAncho";
            this.labelAncho.Size = new System.Drawing.Size(59, 20);
            this.labelAncho.TabIndex = 28;
            this.labelAncho.Text = "Ancho:";
            // 
            // labelAlto
            // 
            this.labelAlto.AutoSize = true;
            this.labelAlto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAlto.Location = new System.Drawing.Point(330, 161);
            this.labelAlto.Name = "labelAlto";
            this.labelAlto.Size = new System.Drawing.Size(41, 20);
            this.labelAlto.TabIndex = 27;
            this.labelAlto.Text = "Alto:";
            // 
            // buttonCambiarResolucion
            // 
            this.buttonCambiarResolucion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCambiarResolucion.Location = new System.Drawing.Point(251, 264);
            this.buttonCambiarResolucion.Name = "buttonCambiarResolucion";
            this.buttonCambiarResolucion.Size = new System.Drawing.Size(90, 35);
            this.buttonCambiarResolucion.TabIndex = 26;
            this.buttonCambiarResolucion.Text = "Cambiar";
            this.buttonCambiarResolucion.UseVisualStyleBackColor = true;
            this.buttonCambiarResolucion.Click += new System.EventHandler(this.button13_Click);
            // 
            // textBoxNuevoArchivo4
            // 
            this.textBoxNuevoArchivo4.Location = new System.Drawing.Point(330, 213);
            this.textBoxNuevoArchivo4.Name = "textBoxNuevoArchivo4";
            this.textBoxNuevoArchivo4.Size = new System.Drawing.Size(169, 20);
            this.textBoxNuevoArchivo4.TabIndex = 25;
            // 
            // labelNuevoArchivo4
            // 
            this.labelNuevoArchivo4.AutoSize = true;
            this.labelNuevoArchivo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNuevoArchivo4.Location = new System.Drawing.Point(96, 214);
            this.labelNuevoArchivo4.Name = "labelNuevoArchivo4";
            this.labelNuevoArchivo4.Size = new System.Drawing.Size(228, 17);
            this.labelNuevoArchivo4.TabIndex = 24;
            this.labelNuevoArchivo4.Text = "Colocar nuevo nombre del archivo:";
            // 
            // buttonBuscar4
            // 
            this.buttonBuscar4.Location = new System.Drawing.Point(377, 107);
            this.buttonBuscar4.Name = "buttonBuscar4";
            this.buttonBuscar4.Size = new System.Drawing.Size(75, 23);
            this.buttonBuscar4.TabIndex = 23;
            this.buttonBuscar4.Text = "Buscar";
            this.buttonBuscar4.UseVisualStyleBackColor = true;
            this.buttonBuscar4.Click += new System.EventHandler(this.button14_Click);
            // 
            // textBoxArchivo4
            // 
            this.textBoxArchivo4.Enabled = false;
            this.textBoxArchivo4.Location = new System.Drawing.Point(156, 109);
            this.textBoxArchivo4.Name = "textBoxArchivo4";
            this.textBoxArchivo4.Size = new System.Drawing.Size(215, 20);
            this.textBoxArchivo4.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(172, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(241, 22);
            this.label10.TabIndex = 21;
            this.label10.Text = "Cambiar resolucion del video";
            // 
            // tabPageExtraerImagen
            // 
            this.tabPageExtraerImagen.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageExtraerImagen.Controls.Add(this.textBoxFps);
            this.tabPageExtraerImagen.Controls.Add(this.labelFps);
            this.tabPageExtraerImagen.Controls.Add(this.buttonExtraerImagen);
            this.tabPageExtraerImagen.Controls.Add(this.textBoxNuevoArchivo5);
            this.tabPageExtraerImagen.Controls.Add(this.labelNuevoArchivo5);
            this.tabPageExtraerImagen.Controls.Add(this.buttonBuscar5);
            this.tabPageExtraerImagen.Controls.Add(this.textBoxArchivo5);
            this.tabPageExtraerImagen.Controls.Add(this.labelExtraerImagen);
            this.tabPageExtraerImagen.Location = new System.Drawing.Point(4, 22);
            this.tabPageExtraerImagen.Name = "tabPageExtraerImagen";
            this.tabPageExtraerImagen.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageExtraerImagen.Size = new System.Drawing.Size(595, 340);
            this.tabPageExtraerImagen.TabIndex = 4;
            this.tabPageExtraerImagen.Text = "tabPage5";
            // 
            // textBoxFps
            // 
            this.textBoxFps.Location = new System.Drawing.Point(330, 164);
            this.textBoxFps.Name = "textBoxFps";
            this.textBoxFps.Size = new System.Drawing.Size(67, 20);
            this.textBoxFps.TabIndex = 28;
            // 
            // labelFps
            // 
            this.labelFps.AutoSize = true;
            this.labelFps.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFps.Location = new System.Drawing.Point(117, 164);
            this.labelFps.Name = "labelFps";
            this.labelFps.Size = new System.Drawing.Size(207, 17);
            this.labelFps.TabIndex = 27;
            this.labelFps.Text = "Cantidad de fotos por segundo:";
            // 
            // buttonExtraerImagen
            // 
            this.buttonExtraerImagen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExtraerImagen.Location = new System.Drawing.Point(255, 264);
            this.buttonExtraerImagen.Name = "buttonExtraerImagen";
            this.buttonExtraerImagen.Size = new System.Drawing.Size(90, 35);
            this.buttonExtraerImagen.TabIndex = 26;
            this.buttonExtraerImagen.Text = "Extraer";
            this.buttonExtraerImagen.UseVisualStyleBackColor = true;
            this.buttonExtraerImagen.Click += new System.EventHandler(this.button15_Click);
            // 
            // textBoxNuevoArchivo5
            // 
            this.textBoxNuevoArchivo5.Location = new System.Drawing.Point(330, 213);
            this.textBoxNuevoArchivo5.Name = "textBoxNuevoArchivo5";
            this.textBoxNuevoArchivo5.Size = new System.Drawing.Size(169, 20);
            this.textBoxNuevoArchivo5.TabIndex = 25;
            // 
            // labelNuevoArchivo5
            // 
            this.labelNuevoArchivo5.AutoSize = true;
            this.labelNuevoArchivo5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNuevoArchivo5.Location = new System.Drawing.Point(96, 214);
            this.labelNuevoArchivo5.Name = "labelNuevoArchivo5";
            this.labelNuevoArchivo5.Size = new System.Drawing.Size(228, 17);
            this.labelNuevoArchivo5.TabIndex = 24;
            this.labelNuevoArchivo5.Text = "Colocar nuevo nombre del archivo:";
            // 
            // buttonBuscar5
            // 
            this.buttonBuscar5.Location = new System.Drawing.Point(377, 107);
            this.buttonBuscar5.Name = "buttonBuscar5";
            this.buttonBuscar5.Size = new System.Drawing.Size(75, 23);
            this.buttonBuscar5.TabIndex = 23;
            this.buttonBuscar5.Text = "Buscar";
            this.buttonBuscar5.UseVisualStyleBackColor = true;
            this.buttonBuscar5.Click += new System.EventHandler(this.button16_Click);
            // 
            // textBoxArchivo5
            // 
            this.textBoxArchivo5.Enabled = false;
            this.textBoxArchivo5.Location = new System.Drawing.Point(156, 109);
            this.textBoxArchivo5.Name = "textBoxArchivo5";
            this.textBoxArchivo5.Size = new System.Drawing.Size(215, 20);
            this.textBoxArchivo5.TabIndex = 22;
            // 
            // labelExtraerImagen
            // 
            this.labelExtraerImagen.AutoSize = true;
            this.labelExtraerImagen.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelExtraerImagen.Location = new System.Drawing.Point(198, 51);
            this.labelExtraerImagen.Name = "labelExtraerImagen";
            this.labelExtraerImagen.Size = new System.Drawing.Size(227, 22);
            this.labelExtraerImagen.TabIndex = 21;
            this.labelExtraerImagen.Text = "Extraer imagenes del video";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.labelBienvenido);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(802, 121);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.buttonCerrar);
            this.panel2.Location = new System.Drawing.Point(690, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(111, 121);
            this.panel2.TabIndex = 3;
            // 
            // buttonCerrar
            // 
            this.buttonCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCerrar.Location = new System.Drawing.Point(-1, -1);
            this.buttonCerrar.Name = "buttonCerrar";
            this.buttonCerrar.Size = new System.Drawing.Size(111, 121);
            this.buttonCerrar.TabIndex = 0;
            this.buttonCerrar.Text = "Cerrar";
            this.buttonCerrar.UseVisualStyleBackColor = true;
            this.buttonCerrar.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // labelBienvenido
            // 
            this.labelBienvenido.AutoSize = true;
            this.labelBienvenido.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBienvenido.Location = new System.Drawing.Point(280, 47);
            this.labelBienvenido.Name = "labelBienvenido";
            this.labelBienvenido.Size = new System.Drawing.Size(181, 25);
            this.labelBienvenido.TabIndex = 1;
            this.labelBienvenido.Text = "Bienvenido Usuario";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TabControlPrincipal);
            this.Controls.Add(this.panel3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form2";
            this.Text = "Edicion de videos";
            this.panel3.ResumeLayout(false);
            this.TabControlPrincipal.ResumeLayout(false);
            this.tabPageCambiarFormato.ResumeLayout(false);
            this.tabPageCambiarFormato.PerformLayout();
            this.tabPageExtraerAudio.ResumeLayout(false);
            this.tabPageExtraerAudio.PerformLayout();
            this.tabPageRemoverAudio.ResumeLayout(false);
            this.tabPageRemoverAudio.PerformLayout();
            this.tabPageCambiarResolucion.ResumeLayout(false);
            this.tabPageCambiarResolucion.PerformLayout();
            this.tabPageExtraerImagen.ResumeLayout(false);
            this.tabPageExtraerImagen.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonExtraerImagenDelVideo;
        private System.Windows.Forms.Button buttonCambiarResolucionDelVideo;
        private System.Windows.Forms.Button buttonRemoverAudioDelVideo;
        private System.Windows.Forms.Button buttonExtraerAudioDelVideo;
        private System.Windows.Forms.Button buttonCambiarFormatoDelVideo;
        private System.Windows.Forms.TabControl TabControlPrincipal;
        private System.Windows.Forms.TabPage tabPageCambiarFormato;
        private System.Windows.Forms.TabPage tabPageExtraerAudio;
        private System.Windows.Forms.TabPage tabPageRemoverAudio;
        private System.Windows.Forms.TabPage tabPageCambiarResolucion;
        private System.Windows.Forms.TabPage tabPageExtraerImagen;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonCerrar;
        private System.Windows.Forms.Button buttonConvertirFormato;
        private System.Windows.Forms.TextBox textBoxNuevoArchivo1;
        private System.Windows.Forms.Label labelNuevoArchivo1;
        private System.Windows.Forms.ComboBox comboBoxFormatos;
        private System.Windows.Forms.Label labelSeleccionarFormato;
        private System.Windows.Forms.Button buttonBuscar1;
        private System.Windows.Forms.TextBox textBoxArchivo1;
        private System.Windows.Forms.Label labelCambiarFormato;
        private System.Windows.Forms.Button buttonExtraerAudio;
        private System.Windows.Forms.TextBox textBoxNuevoArchivo2;
        private System.Windows.Forms.Label labelNuevoArchivo2;
        private System.Windows.Forms.Button buttonBuscar2;
        private System.Windows.Forms.TextBox textBoxArchivo2;
        private System.Windows.Forms.Label labelExtraerAudio;
        private System.Windows.Forms.Button buttonRemoverAudio;
        private System.Windows.Forms.TextBox textBoxNuevoArchivo3;
        private System.Windows.Forms.Label labelNuevoArchivo3;
        private System.Windows.Forms.Button buttonBuscar3;
        private System.Windows.Forms.TextBox textBoxArchivo3;
        private System.Windows.Forms.Label labelRemoverAudio;
        private System.Windows.Forms.TextBox textBoxAncho;
        private System.Windows.Forms.TextBox textBoxAlto;
        private System.Windows.Forms.Label labelAncho;
        private System.Windows.Forms.Label labelAlto;
        private System.Windows.Forms.Button buttonCambiarResolucion;
        private System.Windows.Forms.TextBox textBoxNuevoArchivo4;
        private System.Windows.Forms.Label labelNuevoArchivo4;
        private System.Windows.Forms.Button buttonBuscar4;
        private System.Windows.Forms.TextBox textBoxArchivo4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxFps;
        private System.Windows.Forms.Label labelFps;
        private System.Windows.Forms.Button buttonExtraerImagen;
        private System.Windows.Forms.TextBox textBoxNuevoArchivo5;
        private System.Windows.Forms.Label labelNuevoArchivo5;
        private System.Windows.Forms.Button buttonBuscar5;
        private System.Windows.Forms.TextBox textBoxArchivo5;
        private System.Windows.Forms.Label labelExtraerImagen;
        public System.Windows.Forms.Label labelBienvenido;
    }
}